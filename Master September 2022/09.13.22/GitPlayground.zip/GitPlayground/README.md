# GitPlayground

You'll use this folder to practice using git: making changes, committing them, viewing your history, going back to older commits. This file is just a starting point.
