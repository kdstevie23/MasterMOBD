//
//  Notifications.swift
//  Alarm
//

import Foundation

extension Notification.Name {
    static let alarmUpdated = Notification.Name("alarmUpdated")
}
